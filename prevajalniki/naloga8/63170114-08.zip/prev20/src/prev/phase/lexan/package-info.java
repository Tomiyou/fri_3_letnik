/**
 * Lexical analysis.
 */
package prev.phase.lexan;
