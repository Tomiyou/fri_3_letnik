/**
 * Representing types.
 */
package prev.data.semtype;