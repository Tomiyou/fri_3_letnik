/**
 * Abstract syntax tree.
 */
package prev.data.ast.tree;
