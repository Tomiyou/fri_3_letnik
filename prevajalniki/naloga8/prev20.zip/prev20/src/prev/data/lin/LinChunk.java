package prev.data.lin;

/**
 * An abstract chunk of linear code.
 */
public class LinChunk {
}
