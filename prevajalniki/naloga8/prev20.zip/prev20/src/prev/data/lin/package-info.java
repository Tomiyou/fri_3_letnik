/**
 * Chucks of linear intermediate code.
 */
package prev.data.lin;
