/**
 * Compiler for PREV'20 programming language producing MMIX assembly code.
 */
module prev20 {
	requires java.xml;
	requires antlr;
}