package prev.phase.memory;

import prev.data.ast.tree.*;
import prev.data.ast.tree.decl.*;
import prev.data.ast.tree.expr.*;
import prev.data.ast.tree.type.*;
import prev.data.ast.visitor.*;
import prev.data.semtype.*;
import prev.data.mem.*;
import prev.phase.seman.*;

/**
 * Computing memory layout: frames and accesses.
 */
public class MemEvaluator extends AstFullVisitor<Object, MemEvaluator.Context> {

	/**
	 * The context {@link MemEvaluator} uses while computing function frames and
	 * variable accesses.
	 */
	protected abstract class Context {
	}

	/**
	 * Functional context, i.e., used when traversing function and building a new
	 * frame, parameter acceses and variable acceses.
	 */
	private class FunContext extends Context {
		public int depth = 0;
		public long locsSize = 0;
		public long argsSize = 0;
		public long parsSize = new SemPointer(new SemVoid()).size();
	}

	/**
	 * Record context, i.e., used when traversing record definition and computing
	 * record component acceses.
	 */
	private class RecContext extends Context {
		public long compsSize = 0;
	}

	@Override
	public Object visit(AstTrees<? extends AstTree> trees, Context ctx) {
		for (AstTree t : trees)
			if (t != null)
				t.accept(this, ctx);
		return null;
	}

	// DECLARATIONS

	@Override
	public Object visit(AstCompDecl compDecl, Context ctx) {
		if (compDecl.type() != null)
			compDecl.type().accept(this, ctx);

		long size = SemAn.isType.get(compDecl.type()).actualType().size();
		RecContext _ctx = (RecContext) ctx;
		MemAccess acc = new MemRelAccess(size, -_ctx.compsSize, 0);
		_ctx.compsSize += size;

		return Memory.accesses.put(compDecl, acc);
	}

	@Override
	public Object visit(AstFunDecl funDecl, Context ctx) {
		int depth = ctx == null ? 0 : ((FunContext) ctx).depth + 1;
		FunContext newCtx = new FunContext();
		newCtx.depth = depth;

		if (funDecl.pars() != null)
			funDecl.pars().accept(this, newCtx);
		if (funDecl.type() != null)
			funDecl.type().accept(this, newCtx);
		if (funDecl.expr() != null)
			funDecl.expr().accept(this, newCtx);

		long retSize = Math.max(SemAn.ofType.get(funDecl.expr()).actualType().size(), newCtx.argsSize + 8);

		Memory.frames.put(funDecl,
				new MemFrame(new MemLabel(funDecl.name()), 0, newCtx.locsSize, retSize));

		return null;
	}

	@Override
	public Object visit(AstParDecl parDecl, Context ctx) {
		if (parDecl.type() != null)
			parDecl.type().accept(this, ctx);

		FunContext _ctx = (FunContext) ctx;
		long size = SemAn.isType.get(parDecl.type()).actualType().size();
		Memory.accesses.put(parDecl, new MemRelAccess(size, _ctx.parsSize, _ctx.depth));
		_ctx.parsSize += size;
		return null;
	}

	@Override
	public Object visit(AstTypeDecl typeDecl, Context ctx) {
		if (typeDecl.type() != null)
			typeDecl.type().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstVarDecl varDecl, Context ctx) {
		if (varDecl.type() != null)
			varDecl.type().accept(this, ctx);

		long size = SemAn.isType.get(varDecl.type()).actualType().size();
		MemAccess acc;
		if (ctx == null) {
			acc = new MemAbsAccess(size, new MemLabel(varDecl.name()));
		} else {
			FunContext _ctx = (FunContext) ctx;
			_ctx.locsSize += size;
			acc = new MemRelAccess(size, -_ctx.locsSize, _ctx.depth);
		}

		return Memory.accesses.put(varDecl, acc);
	}

	// EXPRESSIONS

	@Override
	public Object visit(AstArrExpr arrExpr, Context ctx) {
		if (arrExpr.arr() != null)
			arrExpr.arr().accept(this, ctx);
		if (arrExpr.idx() != null)
			arrExpr.idx().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstAtomExpr atomExpr, Context ctx) {
		if (atomExpr.type() == AstAtomExpr.Type.STRING) {
			long size = atomExpr.value().length() * 8;
			// long size = SemAn.ofType.get(atomExpr).actualType();
			Memory.strings.put(atomExpr, new MemAbsAccess(size, new MemLabel(atomExpr.value()), atomExpr.value()));
		}
		return null;
	}

	@Override
	public Object visit(AstBinExpr binExpr, Context ctx) {
		if (binExpr.fstExpr() != null)
			binExpr.fstExpr().accept(this, ctx);
		if (binExpr.sndExpr() != null)
			binExpr.sndExpr().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstCallExpr callExpr, Context ctx) {
		if (callExpr.args() != null)
			callExpr.args().accept(this, ctx);

		long parsSize = 0;
		for (AstExpr expr : callExpr.args()) {
			SemType typ = SemAn.ofType.get(expr).actualType();
			parsSize += typ.size();
		}

		FunContext _ctx = (FunContext) ctx;
		if (_ctx.argsSize < parsSize)
			_ctx.argsSize = parsSize;

		return null;
	}

	@Override
	public Object visit(AstCastExpr castExpr, Context ctx) {
		if (castExpr.expr() != null)
			castExpr.expr().accept(this, ctx);
		if (castExpr.type() != null)
			castExpr.type().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstNameExpr nameExpr, Context ctx) {
		return null;
	}

	@Override
	public Object visit(AstPfxExpr pfxExpr, Context ctx) {
		if (pfxExpr.expr() != null)
			pfxExpr.expr().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstRecExpr recExpr, Context ctx) {
		if (recExpr.rec() != null)
			recExpr.rec().accept(this, ctx);
		if (recExpr.comp() != null)
			recExpr.comp().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstSfxExpr sfxExpr, Context ctx) {
		if (sfxExpr.expr() != null)
			sfxExpr.expr().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstStmtExpr stmtExpr, Context ctx) {
		if (stmtExpr.stmts() != null)
			stmtExpr.stmts().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstWhereExpr whereExpr, Context ctx) {
		if (whereExpr.expr() != null)
			whereExpr.expr().accept(this, ctx);
		if (whereExpr.decls() != null)
			whereExpr.decls().accept(this, ctx);
		return null;
	}

	// TYPES

	@Override
	public Object visit(AstArrType arrType, Context ctx) {
		if (arrType.elemType() != null)
			arrType.elemType().accept(this, ctx);
		if (arrType.numElems() != null)
			arrType.numElems().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstAtomType atomType, Context ctx) {
		return null;
	}

	@Override
	public Object visit(AstNameType nameType, Context ctx) {
		return null;
	}

	@Override
	public Object visit(AstPtrType ptrType, Context ctx) {
		if (ptrType.baseType() != null)
			ptrType.baseType().accept(this, ctx);
		return null;
	}

	@Override
	public Object visit(AstRecType recType, Context ctx) {
		RecContext newCtx = new RecContext();

		if (recType.comps() != null)
			recType.comps().accept(this, newCtx);
		return null;
	}

}
