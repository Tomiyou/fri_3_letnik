/**
 * Memory layout: frames and accesses.
 */
package prev.data.mem;
