package prev.data.imc.code.stmt;

import prev.data.imc.code.*;

/**
 * Intermediate code instruction denoting a statement.
 */
public abstract class ImcStmt extends ImcInstr {
}
