/**
 * Intermediate code instructions denoting statements.
 */
package prev.data.imc.code.stmt;
