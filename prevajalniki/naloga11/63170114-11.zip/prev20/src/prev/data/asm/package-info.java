/**
 * Machine code.
 */
package prev.data.asm;