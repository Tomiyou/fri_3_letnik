/**
 * Abstract syntax tree: representing types.
 */
package prev.data.ast.tree.type;
