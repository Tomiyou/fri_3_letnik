/**
 * Machine code generation.
 */
package prev.phase.asmgen;