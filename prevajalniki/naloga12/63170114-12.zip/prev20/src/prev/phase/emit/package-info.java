/**
 * Register allocation.
 */
package prev.phase.emit;