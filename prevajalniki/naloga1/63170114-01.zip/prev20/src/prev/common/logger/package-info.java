/**
 * Infrastructure for producing logs of individual compiler phases.
 */
package prev.common.logger;
