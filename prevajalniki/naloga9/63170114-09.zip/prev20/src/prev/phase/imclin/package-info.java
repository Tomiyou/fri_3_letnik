/**
 * Intermediate code linearization.
 */
package prev.phase.imclin;